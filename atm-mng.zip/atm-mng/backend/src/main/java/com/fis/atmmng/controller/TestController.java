
package com.fis.atmmng.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/test")
@Api(value = "atm-mng-application", description = "Operations pertaining to user management in the Data Capture Portal application")
public class TestController
{
    @Value("${spring.application.name}")
    String appName;

    @GetMapping("/name")
    public String getAppName()
    {
        return appName;
    }

}
